import { redirect } from "next/navigation";
import { LINKEDIN_PROFILE } from "@/lib/content";

export default function ConnectPage() {
  // Immediate redirect to LinkedIn profile
  redirect(LINKEDIN_PROFILE);
}
