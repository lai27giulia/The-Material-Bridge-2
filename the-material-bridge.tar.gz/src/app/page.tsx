"use client";

import { useLanguage } from "@/context/LanguageContext";

export default function Home() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <main className="min-h-screen bg-brutalist-dirty">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-5xl font-black mb-4 border-4 border-black p-4">
          The Material Bridge
        </h1>
        
        <p className="text-lg mb-6 font-bold">
          Current Language: <span className="text-brutalist-safety">{language.toUpperCase()}</span>
        </p>

        <div className="flex gap-4 mb-8">
          <button
            onClick={() => setLanguage("es")}
            className={`px-6 py-3 font-bold border-4 border-black ${
              language === "es"
                ? "bg-brutalist-safety text-black"
                : "bg-white text-black hover:bg-brutalist-steel"
            }`}
          >
            Español
          </button>
          <button
            onClick={() => setLanguage("en")}
            className={`px-6 py-3 font-bold border-4 border-black ${
              language === "en"
                ? "bg-brutalist-safety text-black"
                : "bg-white text-black hover:bg-brutalist-steel"
            }`}
          >
            English
          </button>
        </div>

        <div className="border-4 border-black p-6 bg-white mb-8">
          <h2 className="text-2xl font-bold mb-4">✓ Initialization Complete</h2>
          <ul className="space-y-2 font-mono text-sm">
            <li>✓ Next.js App Router configured</li>
            <li>✓ Tailwind CSS with Brutalist theme</li>
            <li>✓ Language Context (i18n) initialized</li>
            <li>✓ Audio Context setup (muted by default)</li>
            <li>✓ Data Schema & Seed Data loaded</li>
            <li>✓ TypeScript types defined</li>
          </ul>
        </div>

        <div className="border-4 border-black p-6 bg-white">
          <h2 className="text-2xl font-bold mb-4">📋 Next Steps (Task 2)</h2>
          <ol className="space-y-2 font-mono text-sm list-decimal list-inside">
            <li>Build Hero Section Component</li>
            <li>Build Language Toggle Component</li>
            <li>Build Interactive Case Study Component</li>
            <li>Build Technical Vault Component</li>
            <li>Build Audio Engine Component</li>
            <li>Build Brutal CTA Widget</li>
            <li>Build Footer & Ticker Bar</li>
            <li>Assemble Full Page Layout</li>
          </ol>
        </div>
      </div>
    </main>
  );
}
