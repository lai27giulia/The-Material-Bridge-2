import { useLanguage } from "@/context/LanguageContext";

/**
 * Privacy Policy Page
 * 
 * Detailed privacy statement per GDPR compliance.
 * Accessible via /privacy route.
 */

export default function PrivacyPage() {
  const { t } = useLanguage();

  return (
    <main className="w-full bg-brutalist-dirty">
      {/* Header */}
      <div className="border-b-4 border-black p-6 md:p-8 lg:p-12 bg-white">
        <h1 className="text-4xl md:text-5xl font-black mb-4">
          {t({
            es: "Política de Privacidad",
            en: "Privacy Policy",
          })}
        </h1>
        <p className="text-base md:text-lg font-bold text-brutalist-steel">
          {t({
            es: "Última actualización: Enero 2025",
            en: "Last updated: January 2025",
          })}
        </p>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-6 md:p-8 lg:p-12 bg-white border-b-4 border-black">
        {/* Section 1: Overview */}
        <section className="mb-12 border-b-4 border-black pb-8">
          <h2 className="text-3xl font-black mb-4">
            {t({
              es: "1. Resumen Ejecutivo",
              en: "1. Executive Summary",
            })}
          </h2>
          <p className="text-lg font-bold leading-relaxed mb-4">
            {t({
              es: "Este sitio web está diseñado con privacidad por defecto. NO recopilamos datos personales, NO utilizamos cookies y NO rastreamos usuarios.",
              en: "This website is designed with privacy by default. We do NOT collect personal data, we do NOT use cookies, and we do NOT track users.",
            })}
          </p>
          <p className="text-base font-bold leading-relaxed">
            {t({
              es: "Cumplimos totalmente con el Reglamento General de Protección de Datos (RGPD) de la Unión Europea.",
              en: "We fully comply with the EU's General Data Protection Regulation (GDPR).",
            })}
          </p>
        </section>

        {/* Section 2: Data Collection */}
        <section className="mb-12 border-b-4 border-black pb-8">
          <h2 className="text-3xl font-black mb-4">
            {t({
              es: "2. Recopilación de Datos",
              en: "2. Data Collection",
            })}
          </h2>

          <h3 className="text-xl font-bold mb-3 text-brutalist-steel uppercase">
            {t({
              es: "Lo que NO recopilamos:",
              en: "What We Do NOT Collect:",
            })}
          </h3>

          <ul className="space-y-3 mb-6">
            <li className="flex gap-3 text-base font-bold">
              <span className="text-brutalist-safety font-mono">✗</span>
              <span>
                {t({
                  es: "Identificadores personales (nombre, email, dirección IP)",
                  en: "Personal identifiers (name, email, IP address)",
                })}
              </span>
            </li>
            <li className="flex gap-3 text-base font-bold">
              <span className="text-brutalist-safety font-mono">✗</span>
              <span>
                {t({
                  es: "Datos de navegación (páginas visitadas, duración de sesión)",
                  en: "Navigation data (pages visited, session duration)",
                })}
              </span>
            </li>
            <li className="flex gap-3 text-base font-bold">
              <span className="text-brutalist-safety font-mono">✗</span>
              <span>
                {t({
                  es: "Cookies o tokens de seguimiento",
                  en: "Cookies or tracking tokens",
                })}
              </span>
            </li>
            <li className="flex gap-3 text-base font-bold">
              <span className="text-brutalist-safety font-mono">✗</span>
              <span>
                {t({
                  es: "Información de dispositivo (OS, navegador, resolución)",
                  en: "Device information (OS, browser, resolution)",
                })}
              </span>
            </li>
            <li className="flex gap-3 text-base font-bold">
              <span className="text-brutalist-safety font-mono">✗</span>
              <span>
                {t({
                  es: "Datos de ubicación o geolocalización",
                  en: "Location or geolocation data",
                })}
              </span>
            </li>
          </ul>

          <h3 className="text-xl font-bold mb-3 text-brutalist-steel uppercase">
            {t({
              es: "Lo que SÍ almacenamos (LOCAL SOLO):",
              en: "What We DO Store (LOCALLY ONLY):",
            })}
          </h3>

          <div className="border-4 border-black p-4 mb-6 bg-brutalist-dirty">
            <p className="text-base font-bold mb-3">
              {t({
                es: "Preferencias del usuario en tu navegador (localStorage):",
                en: "User preferences in your browser (localStorage):",
              })}
            </p>
            <ul className="space-y-2 text-sm font-mono ml-4">
              <li className="text-brutalist-steel">
                • <span className="text-black">preferred-language</span>: "es" o "en"
              </li>
              <li className="text-brutalist-steel">
                • <span className="text-black">audio-muted</span>: true o false
              </li>
              <li className="text-brutalist-steel">
                • <span className="text-black">audio-volume</span>: 0-1 (número)
              </li>
            </ul>
            <p className="text-xs font-bold mt-3 text-brutalist-steel">
              {t({
                es: "Estos datos se almacenan ÚNICAMENTE en tu dispositivo, NO se envían a nuestros servidores.",
                en: "This data is stored ONLY on your device, NOT sent to our servers.",
              })}
            </p>
          </div>
        </section>

        {/* Section 3: No Analytics */}
        <section className="mb-12 border-b-4 border-black pb-8">
          <h2 className="text-3xl font-black mb-4">
            {t({
              es: "3. Sin Analítica ni Seguimiento",
              en: "3. No Analytics or Tracking",
            })}
          </h2>

          <p className="text-base font-bold leading-relaxed mb-4">
            {t({
              es: "Este sitio NO utiliza:",
              en: "This website does NOT use:",
            })}
          </p>

          <div className="space-y-3">
            <div className="border-l-4 border-brutalist-safety pl-4">
              <p className="font-bold text-base">Google Analytics</p>
              <p className="text-sm text-brutalist-steel">
                {t({
                  es: "No rastreamos métricas de usuario ni comportamiento",
                  en: "We don't track user metrics or behavior",
                })}
              </p>
            </div>

            <div className="border-l-4 border-brutalist-safety pl-4">
              <p className="font-bold text-base">Hotjar, Mixpanel, o similares</p>
              <p className="text-sm text-brutalist-steel">
                {t({
                  es: "No hay heatmaps, recordings o session replays",
                  en: "No heatmaps, recordings, or session replays",
                })}
              </p>
            </div>

            <div className="border-l-4 border-brutalist-safety pl-4">
              <p className="font-bold text-base">Scripts de Terceros</p>
              <p className="text-sm text-brutalist-steel">
                {t({
                  es: "No hay Facebook Pixel, pixels de publicidad o trackers sociales",
                  en: "No Facebook Pixel, ad pixels, or social trackers",
                })}
              </p>
            </div>

            <div className="border-l-4 border-brutalist-safety pl-4">
              <p className="font-bold text-base">CDNs de Terceros para Contenido</p>
              <p className="text-sm text-brutalist-steel">
                {t({
                  es: "Todos los recursos se sirven desde nuestros servidores",
                  en: "All resources are served from our servers",
                })}
              </p>
            </div>
          </div>
        </section>

        {/* Section 4: No Cookies */}
        <section className="mb-12 border-b-4 border-black pb-8">
          <h2 className="text-3xl font-black mb-4">
            {t({
              es: "4. Política de Cookies",
              en: "4. Cookie Policy",
            })}
          </h2>

          <div className="border-4 border-brutalist-safety p-6 bg-brutalist-dirty mb-6">
            <h3 className="text-2xl font-black mb-4 text-brutalist-safety">
              {t({
                es: "🍪 CERO COOKIES 🍪",
                en: "🍪 ZERO COOKIES 🍪",
              })}
            </h3>
            <p className="text-lg font-bold">
              {t({
                es: "Este sitio NO instala NINGUNA cookie en tu navegador.",
                en: "This website does NOT install ANY cookies in your browser.",
              })}
            </p>
          </div>

          <p className="text-base font-bold leading-relaxed mb-4">
            {t({
              es: "Por lo tanto:",
              en: "Therefore:",
            })}
          </p>

          <ul className="space-y-2">
            <li className="text-base font-bold">
              ✓ {t({
                es: "No necesitamos banners de consentimiento de cookies",
                en: "We don't need cookie consent banners",
              })}
            </li>
            <li className="text-base font-bold">
              ✓ {t({
                es: "Tu navegador no almacena datos persistentes de rastreo",
                en: "Your browser doesn't store persistent tracking data",
              })}
            </li>
            <li className="text-base font-bold">
              ✓ {t({
                es: "Cumplimos automáticamente con RGPD/GDPR en este aspecto",
                en: "We automatically comply with GDPR on this aspect",
              })}
            </li>
          </ul>
        </section>

        {/* Section 5: GDPR Rights */}
        <section className="mb-12 border-b-4 border-black pb-8">
          <h2 className="text-3xl font-black mb-4">
            {t({
              es: "5. Tus Derechos RGPD",
              en: "5. Your GDPR Rights",
            })}
          </h2>

          <p className="text-base font-bold leading-relaxed mb-6">
            {t({
              es: "Aunque no recopilamos datos, tienes estos derechos según el RGPD:",
              en: "Although we don't collect data, you have these rights under GDPR:",
            })}
          </p>

          <div className="space-y-4">
            <div className="border-4 border-black p-4 bg-white">
              <h4 className="font-bold text-lg mb-2">
                {t({
                  es: "Derecho de Acceso",
                  en: "Right of Access",
                })}
              </h4>
              <p className="text-sm font-bold text-brutalist-steel">
                {t({
                  es: "Solicitar acceso a datos personales recopilados.",
                  en: "Request access to collected personal data.",
                })}
              </p>
              <p className="text-sm font-bold mt-2">
                {t({
                  es: "→ Respuesta: No recopilamos datos personales.",
                  en: "→ Response: We don't collect personal data.",
                })}
              </p>
            </div>

            <div className="border-4 border-black p-4 bg-white">
              <h4 className="font-bold text-lg mb-2">
                {t({
                  es: "Derecho de Rectificación",
                  en: "Right of Rectification",
                })}
              </h4>
              <p className="text-sm font-bold text-brutalist-steel">
                {t({
                  es: "Corregir datos personales inexactos.",
                  en: "Correct inaccurate personal data.",
                })}
              </p>
              <p className="text-sm font-bold mt-2">
                {t({
                  es: "→ Respuesta: No hay datos para rectificar.",
                  en: "→ Response: No data to rectify.",
                })}
              </p>
            </div>

            <div className="border-4 border-black p-4 bg-white">
              <h4 className="font-bold text-lg mb-2">
                {t({
                  es: "Derecho al Olvido",
                  en: "Right to Erasure",
                })}
              </h4>
              <p className="text-sm font-bold text-brutalist-steel">
                {t({
                  es: "Solicitar eliminación de datos personales.",
                  en: "Request deletion of personal data.",
                })}
              </p>
              <p className="text-sm font-bold mt-2">
                {t({
                  es: "→ Respuesta: No hay datos almacenados para eliminar.",
                  en: "→ Response: No data stored to delete.",
                })}
              </p>
            </div>

            <div className="border-4 border-black p-4 bg-white">
              <h4 className="font-bold text-lg mb-2">
                {t({
                  es: "Derecho a la Portabilidad",
                  en: "Right to Data Portability",
                })}
              </h4>
              <p className="text-sm font-bold text-brutalist-steel">
                {t({
                  es: "Obtener datos en formato estructurado.",
                  en: "Obtain data in structured format.",
                })}
              </p>
              <p className="text-sm font-bold mt-2">
                {t({
                  es: "→ Respuesta: Las preferencias del usuario se almacenan localmente en localStorage.",
                  en: "→ Response: User preferences are stored locally in localStorage.",
                })}
              </p>
            </div>
          </div>
        </section>

        {/* Section 6: Contact */}
        <section className="mb-12">
          <h2 className="text-3xl font-black mb-4">
            {t({
              es: "6. Contacto - Autoridad de Privacidad",
              en: "6. Contact - Privacy Authority",
            })}
          </h2>

          <p className="text-base font-bold leading-relaxed mb-6">
            {t({
              es: "Si tienes preguntas sobre privacidad o deseas reportar un incidente:",
              en: "If you have privacy questions or want to report an incident:",
            })}
          </p>

          <div className="border-4 border-black p-6 bg-brutalist-dirty mb-6">
            <p className="font-bold text-lg mb-2">
              {t({
                es: "Contacto de Privacidad",
                en: "Privacy Contact",
              })}
            </p>
            <p className="text-base font-bold">Giulia</p>
            <p className="text-base font-bold">
              <a href="https://linkedin.com/in/your-profile" className="underline">
                LinkedIn Profile
              </a>
            </p>
            <p className="text-base font-bold">
              <a href="mailto:your-email@example.com" className="underline">
                Email
              </a>
            </p>
          </div>

          <p className="text-sm font-bold text-brutalist-steel">
            {t({
              es: "Autoridad Reguladora de Protección de Datos (UE):",
              en: "Data Protection Regulatory Authority (EU):",
            })}
          </p>
          <p className="text-sm font-bold">
            {t({
              es: "Contacta a tu autoridad de protección de datos nacional si consideras que hay una violación de RGPD.",
              en: "Contact your national data protection authority if you believe there's a GDPR violation.",
            })}
          </p>
        </section>
      </div>

      {/* Footer CTA */}
      <div className="border-t-4 border-black p-6 md:p-8 bg-black text-brutalist-dirty">
        <div className="max-w-4xl mx-auto text-center">
          <p className="font-mono text-sm font-bold mb-4">
            {t({
              es: "Privacidad por Diseño | Sin cookies | Sin tracking | Solo ciencia",
              en: "Privacy by Design | No cookies | No tracking | Just science",
            })}
          </p>
          <a
            href="/"
            className="inline-block px-6 py-3 border-4 border-brutalist-safety font-black text-brutalist-safety hover:bg-brutalist-safety hover:text-black transition-all"
          >
            {t({
              es: "Volver al Portafolio",
              en: "Back to Portfolio",
            })}
          </a>
        </div>
      </div>
    </main>
  );
}
